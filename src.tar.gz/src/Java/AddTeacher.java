package Java;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.UIManager;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import Database_DML.*;
public class AddTeacher {

	private JFrame frame;
	private JTextField textField_1;
	private JPasswordField passwordField;
    insert i1=new insert();
    private JTextField textField;
    private JTextField textField_2;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddTeacher window = new AddTeacher();
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AddTeacher() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Add new Teacher");
		frame.getContentPane().setBackground(new Color(51, 51, 51));
		frame.setBounds(0, 0, 1366, 759);
		frame.setExtendedState(6);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		JComboBox comboBox_1 = new JComboBox();
		JLabel lblSyllabusteacherMonitoringSystem = new JLabel("Syllabus Monitoring System");
		lblSyllabusteacherMonitoringSystem.setForeground(UIManager.getColor("OptionPane.questionDialog.titlePane.background"));
		lblSyllabusteacherMonitoringSystem.setFont(new Font("Sawasdee", Font.BOLD, 48));
		lblSyllabusteacherMonitoringSystem.setBackground(UIManager.getColor("Button.foreground"));
		lblSyllabusteacherMonitoringSystem.setBounds(338, 26, 961, 208);
		frame.getContentPane().add(lblSyllabusteacherMonitoringSystem);
		
		JButton button = new JButton("");
		button.setBackground(Color.LIGHT_GRAY);
		button.setBounds(290, 250, 716, 4);
		frame.getContentPane().add(button);
		
		JButton button_1 = new JButton("");
		button_1.setBackground(Color.LIGHT_GRAY);
		button_1.setBounds(290, 676, 716, 4);
		frame.getContentPane().add(button_1);
		
		JLabel label_1 = new JLabel("Mini Project - Database Management System");
		label_1.setForeground(Color.WHITE);
		label_1.setBounds(603, 150, 441, 67);
		frame.getContentPane().add(label_1);
		
		JButton btnLogout = new JButton("Back");
		btnLogout.setForeground(new Color(255, 51, 51));
		btnLogout.setBackground(new Color(51, 51, 51));
		btnLogout.setActionCommand("back");
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			  String s= e.getActionCommand();
			  if(s.equals("back"))
			  {
				  try {
					  frame.dispose();
					new Administrator();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			  }
			
			}
		});
		btnLogout.setBounds(67, 209, 117, 25);
		frame.getContentPane().add(btnLogout);
		
		JLabel lblCreateNewTeacher = new JLabel("Create new User");
		lblCreateNewTeacher.setForeground(new Color(204, 204, 204));
		lblCreateNewTeacher.setFont(new Font("Laksaman", Font.BOLD, 29));
		lblCreateNewTeacher.setBounds(300, 237, 510, 75);
		frame.getContentPane().add(lblCreateNewTeacher);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(102, 102, 102));
		panel.setBounds(328, 349, 622, 286);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		textField_1 = new JTextField();
		textField_1.setBounds(254, 125, 242, 19);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(254, 162, 242, 19);
		panel.add(passwordField);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Mr.", "Mrs.", "Miss."}));
		comboBox.setBounds(254, 91, 51, 19);
		panel.add(comboBox);
		
		JLabel lblFullName = new JLabel("Full name");
		lblFullName.setForeground(new Color(255, 255, 255));
		lblFullName.setBounds(162, 93, 84, 15);
		panel.add(lblFullName);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setForeground(new Color(255, 255, 255));
		lblUsername.setBounds(162, 127, 84, 15);
		panel.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setForeground(new Color(255, 255, 255));
		lblPassword.setBounds(162, 164, 70, 15);
		panel.add(lblPassword);
		
		JButton btnCreateAccount = new JButton("Create Account");
		btnCreateAccount.setActionCommand("create");
		btnCreateAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String s=e.getActionCommand();
			String fname = new String( comboBox.getSelectedItem()+textField.getText());
			String lname = new String(textField_2.getText());
			String uname = new String(textField_1.getText());
			String pass = new String(passwordField.getText());
			String Utype = new String((String) comboBox_1.getSelectedItem());
			if(s.equals("create"))
			{
				try {
					i1.add("user","'"+uname+"','"+fname+"','"+lname+"','"+pass+"','"+Utype+"'");
				
					textField.setText("");
					textField_1.setText("");
					passwordField.setText("");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			}
		});
		btnCreateAccount.setBackground(new Color(204, 204, 204));
		btnCreateAccount.setBounds(354, 209, 142, 25);
		panel.add(btnCreateAccount);
		
		JButton btnSubmit = new JButton("Reset");
		btnSubmit.setActionCommand("reset");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String s= e.getActionCommand();
			if(s.equals("reset"))
			{

				textField.setText(null);
				textField_1.setText(null);
				passwordField.setText(null);
			
			}
			
			}
		});
		btnSubmit.setBackground(new Color(255, 102, 153));
		btnSubmit.setBounds(210, 209, 117, 25);
		panel.add(btnSubmit);
		
		
		comboBox_1.setBackground(Color.LIGHT_GRAY);
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Teacher", "Administrator"}));
		comboBox_1.setBounds(254, 46, 242, 24);
		panel.add(comboBox_1);
		
		JLabel lblUserType = new JLabel("User Type");
		lblUserType.setForeground(Color.WHITE);
		lblUserType.setBounds(162, 51, 102, 15);
		panel.add(lblUserType);
		
		textField = new JTextField();
		textField.setBounds(314, 91, 76, 19);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(396, 91, 102, 19);
		panel.add(textField_2);
		textField_2.setColumns(10);
	}
}
