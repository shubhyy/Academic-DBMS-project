package Database;
import Java.*;
import java.sql.*;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import com.mysql.jdbc.Statement;

public class Validate  {

 Connect c1= new Connect();
 Login l1;

 
        public void Validate1(String username,String passwd,String Utype) throws SQLException, NullPointerException
        {
   try {
        	System.out.println("Entered in Validate");
        	c1.test();
        	c1.st=(Statement) c1.con.createStatement(); 
        	String query = new String("select * from users where username='"+username+"'and password = '"+passwd+"' and Utype='"+Utype+"'");
        	c1.st = (Statement) c1.con.createStatement();	
        	//c1.st.execute("insert into users(username,password,Utype) values ('Nikhil','123','Teacher') ");
        	
        	 ResultSet rs = c1.st.executeQuery(query);
        	     while (rs.next())
        	       {
        	         if ((username.equals(rs.getString("username"))) && (passwd.equals(rs.getString("password"))) && (Utype.equals(rs.getString("Utype"))) )
        	         {
        	         
        	        	
	            		 
        	        	
        	            	 if(Utype.equals("Teacher"))
        	            	 {
        	            		 JOptionPane.showMessageDialog(null, "Teacher Login Successfully");
        	            		 System.out.println("User Verified");
        	            	     new TeacherWindow();
        	            		l1.frame.dispose();
        	            		 
        	            	 }else
        	            		 if(Utype.equals("Administrator"))
        	            		 {
        	            		  JOptionPane.showMessageDialog(null, "Administrator Successfully");
        	            		  System.out.println("User Verified");
        	            		  new Administrator();
        	            		  l1.frame.dispose();
        	            		 }else
        	            		 {
        	            		
        	            		
        	            		 }
        	            break;		 
        	            }
        	         else
        	            		 {
        	            			 JOptionPane.showMessageDialog(null, "Login fail");
        	            		 }
        	 
        	         
   
        	       }
        	       
            rs.close();
        	
   }catch(NullPointerException n1)
   {
   
   }
   }
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Validate v1= new Validate();
 
	}

}
